package com.example.user.adamasmaca;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Sanat extends AppCompatActivity {
    TextView kelime;
    TextView score;
    TextView harfgirinizyazi;
    EditText harf;
    Button dene;
    int sayac = 0;

    ImageView resim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sanat);


        kelime = (TextView) findViewById(R.id.textView);
        harfgirinizyazi = (TextView) findViewById(R.id.textView2);
        harf = (EditText) findViewById(R.id.editText);
        dene = (Button) findViewById(R.id.button);
        resim = (ImageView) findViewById(R.id.imageView);
        score = (TextView) findViewById(R.id.textView5);
        // Kelime listemizi olusturuyoruz


        final String[] kelimeler = {"OPERA", "BEETHOVEN", "ÇELLO", "PİCASSO", "VANGOGH", "MONALİSA"};


        //Bir tane rastgele sayı oluşturuyoruz, kelime listemizdeki kelime sayısı kadar
        final int rastgele = (int) (Math.random() * kelimeler.length);
        //Kullanıcıdan harf alıyoruz
        final String[] gelenharf = {harf.getText().toString()};

        //Rastgele bir kelime secip stringe atıyoruz
        final String secilen = kelimeler[rastgele];
        //Atadıgımız stringi char arraya ceviriyoruz
        final char[] charArray = secilen.toCharArray();


        //chararraya cevirdigimiz kelimedeki harf sayısı kadar "_" koyar
        final char answer[] = new char[secilen.length()];
        // final int score_sayilar[] = new int [24];
        int k;
        for (k = 0; k < charArray.length; k++) {
            answer[k] = '_';
        }
        kelime.setText(answer, 0, k);

        //Resimlerimizi asama asama olacak sekilde kaydettik ve arraye attık
        final int images[] = {R.drawable.sifir, R.drawable.bir, R.drawable.iki, R.drawable.uc, R.drawable.dort, R.drawable.bes, R.drawable.son};

        resim.setImageResource(images[0]);

        dene.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = 0;
                int p;
                int k = 0;


                gelenharf[0] = harf.getText().toString();
                for (p = 0; p < charArray.length; p++) {
                    if (gelenharf[0].equals(String.valueOf(charArray[p]))) {
                        answer[p] = gelenharf[0].charAt(0);
                        kelime.setText(String.valueOf(answer));
                    } else {
                        a++;
                    }
                    if (a == charArray.length) {
                        sayac++;
                    }
                    if (sayac == 1) {
                        harfgirinizyazi.setText("1 Hakkınız Gitti, Kelimeniz " + charArray.length + " Harften Olusuyor");
                        resim.setImageResource(images[1]);
                    } else if (sayac == 2) {
                        harfgirinizyazi.setText("2 Hakkınız Gitti");
                        resim.setImageResource(images[2]);
                    } else if (sayac == 3) {
                        harfgirinizyazi.setText("3 Hakkınız Gitti");
                        resim.setImageResource(images[3]);
                    } else if (sayac == 4) {
                        harfgirinizyazi.setText("4 Hakkınız Gitti");
                        resim.setImageResource(images[4]);
                    } else if (sayac == 5) {
                        harfgirinizyazi.setText("5 Hakkınız Gitti");
                        resim.setImageResource(images[5]);
                    } else if (sayac == 6) {
                        harfgirinizyazi.setText("6 Hakkınız Gitti");
                        resim.setImageResource(images[6]);
                        kelime.setText("Kaybettiniz, " + secilen.toString() + " kelimesini bilemediniz");
                        dene.setText("Tekrar Oyna");
                        dene.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                TekrarOyna();
                            }
                        });
                    }
                }
                String cevap = String.valueOf(answer);
                harf.setText("");

                if (cevap.equals(secilen)) {


                    kelime.setText("Tebrikler Bildiniz!");
                    // score.setText(String.valueOf(score_sayilar[k]));
                    dene.setText("Tekrar Oyna");
                    dene.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onClick(v);
                        }
                    });


                }
            }
        });


    }

    public void TekrarOyna() {
        Intent i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public void btn_geri2(View v) {
        Intent intent = new Intent(Sanat.this, kategoriler.class);
        startActivity(intent);

    }
}